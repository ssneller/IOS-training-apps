//
//  main.m
//  Github Friend
//
//  Created by Rene Candelier on 7/24/14.
//  Copyright (c) 2014 Novus Mobile. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GFAAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([GFAAppDelegate class]));
    }
}
